<?php
require_once("includes/config.php");
$sql_user = "sshfree";
$sql_host = "localhost";
$sql_name = "sshfree";

$sql_file = fopen('sshfree.sql', 'r');
$sql = fread($sql_file, filesize('sshfree.sql'));
$conn = new PDO("mysql:host=" . $sql_host . ";dbname=" . $sql_name , $sql_user, $sql_pass);
$conn->exec($sql); ?>