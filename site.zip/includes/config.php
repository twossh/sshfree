<?php

// MySQL Hostname / Server (for eg: 'localhost')
$sql_host = 'localhost';


// MySQL Database Name
$sql_name = 'sshfree';


// MySQL Database User
$sql_user = 'sshfree';


// MySQL Database Password
$sql_pass = 'SENHA';


//Senha do admin
$passw = "admin";

