-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 22-Out-2019 às 11:33
-- Versão do servidor: 10.0.38-MariaDB-0ubuntu0.16.04.1
-- PHP Version: 7.0.33-0ubuntu0.16.04.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sshfree`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `conf`
--

CREATE TABLE `conf` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `com` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `conf`
--

INSERT INTO `conf` (`id`, `nome`, `com`) VALUES
(1, 'Nome do site', 'SSHFREE'),
(3, 'Validade em Horas', '24'),
(4, 'Link do grupo no telegram', 'https://t.me/todososmetodosfree');

-- --------------------------------------------------------

--
-- Estrutura da tabela `serves`
--

CREATE TABLE `serves` (
  `id` int(11) NOT NULL,
  `server` int(11) NOT NULL,
  `paisserver` varchar(30) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `img` text NOT NULL,
  `portassh` varchar(30) NOT NULL,
  `torrent` varchar(30) NOT NULL,
  `trafego` text NOT NULL,
  `login` varchar(30) NOT NULL,
  `velocidade` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sshfree`
--

CREATE TABLE `sshfree` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `senha` varchar(20) NOT NULL,
  `tempo` varchar(50) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `iphost` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `conf`
--
ALTER TABLE `conf`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `serves`
--
ALTER TABLE `serves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sshfree`
--
ALTER TABLE `sshfree`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `conf`
--
ALTER TABLE `conf`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `serves`
--
ALTER TABLE `serves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `sshfree`
--
ALTER TABLE `sshfree`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
